package com.calendar.page.example.example

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
